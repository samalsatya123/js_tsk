let chemicals = [
    { chemical_name: "Water", vendor: "Supplier A", density: 1000, viscosity: 0.001, packaging: "Bottle", pack_size: 1, unit: "L", quantity: 100 },
    { chemical_name: "Ethanol", vendor: "Supplier B", density: 789, viscosity: 0.0012, packaging: "Drum", pack_size: 5, unit: "L", quantity: 50 },
    { chemical_name: "Methanol", vendor: "Supplier C", density: 792, viscosity: 0.00059, packaging: "Bottle", pack_size: 2, unit: "L", quantity: 120 },
    { chemical_name: "Acetone", vendor: "Supplier D", density: 784, viscosity: 0.003, packaging: "Can", pack_size: 10, unit: "L", quantity: 30 },
    { chemical_name: "Hydrochloric Acid", vendor: "Supplier E", density: 1190, viscosity: 0.0019, packaging: "Bottle", pack_size: 1, unit: "L", quantity: 75 },
    { chemical_name: "Sulfuric Acid", vendor: "Supplier F", density: 1830, viscosity: 0.025, packaging: "Drum", pack_size: 25, unit: "L", quantity: 20 },
    { chemical_name: "Sodium Hydroxide", vendor: "Supplier G", density: 2130, viscosity: 0.052, packaging: "Bag", pack_size: 50, unit: "kg", quantity: 60 },
    { chemical_name: "Ammonium Hydroxide", vendor: "Supplier H", density: 880, viscosity: 0.0015, packaging: "Bottle", pack_size: 5, unit: "L", quantity: 40 },
    { chemical_name: "Chloroform", vendor: "Supplier I", density: 1480, viscosity: 0.0058, packaging: "Can", pack_size: 20, unit: "L", quantity: 10 },
];

let selectedRowIndex = null;
//data populating
function populateTable() {
    const tableBody = document.getElementById('chemical-table-body');
    tableBody.innerHTML = '';
    chemicals.forEach((chemical, index) => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td><input type="checkbox" onchange="selectRow(${index})"></td>
            <td>${chemical.chemical_name}</td>
            <td>${chemical.vendor}</td>
            <td>${chemical.density}</td>
            <td>${chemical.viscosity}</td>
            <td>${chemical.packaging}</td>
            <td>${chemical.pack_size}</td>
            <td>${chemical.unit}</td>
            <td>${chemical.quantity}</td>
        `;
        tableBody.appendChild(row);
    });
}

function selectRow(index) {
    const checkboxes = document.querySelectorAll('#chemical-table-body input[type="checkbox"]');
    checkboxes.forEach((checkbox, i) => {
        checkbox.checked = i === index;
    });
    selectedRowIndex = index;
    updateButtonStates();
}

function updateButtonStates() {
    document.getElementById('edit-row').disabled = selectedRowIndex === null;
    document.getElementById('delete-row').disabled = selectedRowIndex === null;
    document.getElementById('move-up').disabled = selectedRowIndex <= 0;
    document.getElementById('move-down').disabled = selectedRowIndex === null || selectedRowIndex >= chemicals.length - 1;
}

function openModal(isEdit = false) {
    const modal = document.getElementById('modal');
    if (isEdit) {
        const chemical = chemicals[selectedRowIndex];
        document.getElementById('chemical_name').value = chemical.chemical_name;
        document.getElementById('vendor').value = chemical.vendor;
        document.getElementById('density').value = chemical.density;
        document.getElementById('viscosity').value = chemical.viscosity;
        document.getElementById('packaging').value = chemical.packaging;
        document.getElementById('pack_size').value = chemical.pack_size;
        document.getElementById('unit').value = chemical.unit;
        document.getElementById('quantity').value = chemical.quantity;
    } else {
        document.querySelectorAll('#modal input').forEach(input => input.value = '');
    }
    modal.style.display = 'flex';
}

function closeModal() {
    document.getElementById('modal').style.display = 'none';
}

function handleModalSubmit() {
    const chemicalName = document.getElementById('chemical_name').value;
    const vendor = document.getElementById('vendor').value;
    const density = document.getElementById('density').value;
    const viscosity = document.getElementById('viscosity').value;
    const packaging = document.getElementById('packaging').value;
    const packSize = document.getElementById('pack_size').value;
    const unit = document.getElementById('unit').value;
    const quantity = document.getElementById('quantity').value;

    // Checking if any of the values are empty
    if (!chemicalName || !vendor || !density || !viscosity || !packaging || !packSize || !unit || !quantity) {
        alert("Please fill out all fields.");
        return;
    }

    // Creating the chemical object
    const chemical = {
        chemical_name: chemicalName,
        vendor: vendor,
        density: parseFloat(density),
        viscosity: parseFloat(viscosity),
        packaging: packaging,
        pack_size: parseFloat(packSize),
        unit: unit,
        quantity: parseInt(quantity)
    };

    // Updating or add the chemical to the array
    if (selectedRowIndex !== null) {
        chemicals[selectedRowIndex] = chemical;
    } else {
        chemicals.push(chemical);
    }

    // Closing the modal and refresh the table
    closeModal();
    populateTable();
    selectedRowIndex = null;
    updateButtonStates();
}

function deleteRow() {
    if (selectedRowIndex !== null) {
        chemicals.splice(selectedRowIndex, 1);
        populateTable();
        selectedRowIndex = null;
        updateButtonStates();
    }
}

function moveRow(direction) {
    if (selectedRowIndex === null) return;
    const targetIndex = direction === 'up' ? selectedRowIndex - 1 : selectedRowIndex + 1;
    if (targetIndex >= 0 && targetIndex < chemicals.length) {
        [chemicals[selectedRowIndex], chemicals[targetIndex]] = [chemicals[targetIndex], chemicals[selectedRowIndex]];
        selectedRowIndex = targetIndex;
        populateTable();
        updateButtonStates();
    }
}

function sortTable(key) {
    chemicals.sort((a, b) => {
        if (typeof a[key] === 'string') {
            return a[key].localeCompare(b[key]);
        } else {
            return a[key] - b[key];
        }
    });
    populateTable();
}

function saveData() {
    console.log("Data saved:", chemicals);
    alert("Data saved successfully!");
}
document.getElementById('add-row').addEventListener('click', () => openModal(false));
document.getElementById('edit-row').addEventListener('click', () => openModal(true));
document.getElementById('delete-row').addEventListener('click', deleteRow);
document.getElementById('move-up').addEventListener('click', () => moveRow('up'));
document.getElementById('move-down').addEventListener('click', () => moveRow('down'));
document.getElementById('refresh-data').addEventListener('click', populateTable);
document.getElementById('save-data').addEventListener('click', saveData);
document.getElementById('cancelModal').addEventListener('click', closeModal);
document.getElementById('submitModal').addEventListener('click', handleModalSubmit);
// Initial population
populateTable();